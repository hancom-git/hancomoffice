<?php
/**
 *
 * (c) Copyright Hancom, Inc.
 *
 */

namespace OCA\HancomOffice\AppInfo;

$app = \OC::$server->query(Application::class);
