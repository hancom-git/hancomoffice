OC.L10N.register(
    "hancomoffice",
    {
        "New document": "Новый документ",
        "New spreadsheet": "Новая таблица",
        "New presentation": "Новая презентация",
        "Edit in Hancom Office": "Открыть в Hancom Office Online",
        "Error opening file": "Возникла ошибка при открытии файла",
        "Loading, please wait.": "Загружается, пожалуйста подождите.",
        "File created": "Файл создан",
        "Error when trying to connect": "Ошибка при попытке подключения",
        "Settings have been successfully updated": "Настройки успешно обновлены"
    },
    "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);"
);
