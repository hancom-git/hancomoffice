<?php
/**
 *
 * (c) Copyright Hancom Inc
 *
 */

    style("hancomoffice", "embed");
    script("hancomoffice", "main");
?>

<iframe src="<?php p($_["url"]) ?>" id="hancomIframe" width="100%" height="100%"></iframe>
